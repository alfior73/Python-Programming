"""
mpenta
in class
functions 1
"""
import math
#import random as r
from random import randint #as rndI


result = math.sqrt(2)
print(result)


randNum = randint(1, 10)
print(randNum)
 

"""
s = type("hello")
print(s)

len("hello world")
min(2, 3, 1)
min("hello")
max("hello")
"""