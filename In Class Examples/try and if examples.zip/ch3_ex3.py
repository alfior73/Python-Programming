"""
mpenta
ex 3.3
grades
"""
letter_grade = ""

print("Enter a number from 0.0 to 1.0")
grade = float(input())

if grade > 1.0 or grade < 0.0:
    print("not a valid grade = try another time")
else:
    #valid grade
    if grade < .6:
        letter_grade = "F"
    elif grade < .7:
        letter_grade = "D"
    elif grade < .8:
        letter_grade = "C"
    elif grade < .9:
        letter_grade = "B"
    else:
        letter_grade = "A"
    
    print(letter_grade)
