"""
mpenta
try except
in-class
"""

try:
    print("enter two number")
    num1 = float(input())
    num2 = float(input())
    print(num1/num2)
    
except:
    print("you cannot divide by zero. try another time")
