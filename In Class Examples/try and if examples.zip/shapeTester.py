"""
mpenta
shape tester in-class
"""
print("Enter a the sides of the shape i a CW order starting at top")
top = int(input())
right = int(input())
bottom = int(input())
left = int(input())

if bottom == top and bottom == left and bottom == right:
    print("that is a square")
elif bottom == top and left == right:
    print("that is a rectangle")
else:
    print("that is quadrileteral")
    
      