


print("enter 2 numbers")
num1 = int(input())
num2 = int(input())


if num1 > num2:
    print("num1 is greater")
elif num2 > num1:
    print("num2 is greater")
else:
    print("they are the same")


"""
print("enter a number")
num = int(input())

if num % 2 == 0:
    print("it is even")
else:
    print("it is odd")
"""