f  = open("hamlet.txt","r")
bigString = f.read().strip()

words = bigString.split(" ")
print(words)

uniqueWords = dict()

for word in words:
    word = word.upper()
    if word in uniqueWords:
        uniqueWords[word] =  uniqueWords[word] + 1
    else:
        #add to dict and set count 1
        uniqueWords[word] = 1

print(uniqueWords)

listKeys = list(uniqueWords.keys())
listKeys.sort()

for k in listKeys:
    print(k + " -> " + str(uniqueWords[k]))



print("pick a word")
w = input().upper()

if w in uniqueWords:
    print(uniqueWords[w])
