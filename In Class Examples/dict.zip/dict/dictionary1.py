
d = dict()
print(d)

d['one'] = 'uno'
d['two'] = 'dos'

print(d)


months = {"dec":12, "jan":1, "feb":2}

print(months)
print(months["feb"])
'''
if "apr" in months:
    print(months["apr"])
else:
    print("not a key")
    print("enter month name")
    m = input()
    print("enter month number")
    mn = int(input())
    months[m] = mn
'''
print(len(months))

keylist = list(months.keys())
vallist = list(months.values())

print(keylist)
print(vallist)


for key in months:
    print(key)
    print(months[key])



