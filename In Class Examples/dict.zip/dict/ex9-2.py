
def drawBar(n):
   print("#" * n)

def printHistogram(d):
    for k in list(d.keys()):
        num = d[k]//10
        print(k, end=" - ")
        drawBar(num)
    
days = {"Mon" : 0, "Tue" : 0, "Wed" : 0, "Thu" : 0, "Fri" : 0, "Sat" : 0, "Sun" : 0 }

f = open("mbox-short.txt")
for line in f:
    if line.startswith("From"):
        words = line.split(" ")
        print(words)
        if len(words) > 2:
            day = words[2]
            days[day] = days[day] + 1

f.close()

print(days)
printHistogram(days)
