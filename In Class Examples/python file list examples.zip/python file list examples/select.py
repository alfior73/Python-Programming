

total = 0

f  = open("docs/myfile.txt","r")

for line in f:
    cost =  line.strip()
    location = cost.find("$")
    moneyStart = location + 1
    moneySubString = cost[moneyStart: ].strip()

    money = float(moneySubString)
    total = total + money
    
print(total)