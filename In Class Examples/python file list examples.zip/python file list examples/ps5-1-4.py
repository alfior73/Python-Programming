#print("name?")
#name = input()


f  = open("docs/myfile.txt","r")

for line in f:
    name = line.strip()
    first = name[0]
    last = name[-1]
    half = len(name)//2
    middle = name[half]

    print(first+middle+last)
