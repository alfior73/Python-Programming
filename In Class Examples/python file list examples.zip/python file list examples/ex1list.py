def chop(l):
    l.pop(0)
    l.pop(-1)
    return None

def middle(l):
    newList = l[1:-1]
    return newList

li = [1, 2, 3, 4, 5,6, 7]

print(li)
chop(li)
print(li)
nl = middle(li)
print(nl)