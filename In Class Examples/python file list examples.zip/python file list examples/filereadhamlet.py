


f  = open("hamlet.txt","r")
bigString = f.read().strip()
#makes a list from a string splittingon the character
words = bigString.split(" ")

uniquewords = []
duplicatewords = []

for word in words:
    ##sanitize your input
    word = word.strip()
    word = word.strip("!?.;,\n")
    word = word.upper()
    
    ##only add to list if the word is not in the list
    if not word in uniquewords:
        uniquewords.append(word)
    else:
        if not word in duplicatewords:
            duplicatewords.append(word)
        else:
            print("already in dupe list")

uniquewords.sort()
print(uniquewords)
print(len(uniquewords))

duplicatewords.sort()
print(duplicatewords)
print(len(duplicatewords))

