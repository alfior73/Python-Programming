#Michael Penta
#Ch2 ex5

factor = 9/5
offset = 32

print("temp in C please")
tempC = float(input())

tempF = tempC * factor + offset

print(str(tempC) + " C is " + str(tempF) + " F")


