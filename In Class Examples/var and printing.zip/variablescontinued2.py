#Michael Penta
#Ch2 ex3

print("Enter hours worked")
hours = int(input())

print("Enter pay rate")
rate = float(input())

totalPay = rate * hours
roundedPay = round(totalPay, 2)

print("your pay is: $" + str(roundedPay))


