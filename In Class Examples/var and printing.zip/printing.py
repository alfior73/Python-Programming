x = 3
y = 5.0
z = "hi"

print(z + " the number is " + str(x))
print(z, " the number is ", x, " . ", sep="")
print("the point is {}, {}".format(x, y))
print(f"The number is {float(x)}")
