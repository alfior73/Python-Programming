"""
Michael Penta
Ch 2 Ex 2
"""
greeting = "ciao"

print("Enter your name")
user_name = input()

print("Enter your age")
user_age = int(input())
new_age = user_age + 1

print(greeting + " " + user_name + "!")
print(user_name + ", your next age will be " + str(new_age))
